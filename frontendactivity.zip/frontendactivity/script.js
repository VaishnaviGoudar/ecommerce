function validateRegisterForm() {
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const password = document.getElementById("password").value;

    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^\d+$/; // Only numbers
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

  
    if (name === "" || email === "" || phone === "" || password === "") {
        alert("All fields are required.");
        return false;
    }
    if (!emailRegex.test(email)) {
        alert("Please enter a valid email address.");
        return false;
    }
    if (!phoneRegex.test(phone)) {
        alert("Please enter a valid phone number (only digits).");
        return false;
    }
    if (!passwordRegex.test(password)) {
        alert("Password must be at least 8 characters long, with at least one uppercase letter, one special symbol, and one number.");
        return false;
    }

    return true; 
}


function validateFeedbackForm() {
    const feedbackName = document.getElementById("feedbackName").value;
    const feedbackEmail = document.getElementById("feedbackEmail").value;
    const feedbackMessage = document.getElementById("feedbackMessage").value;

    // Regular expression for email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    // Validation checks
    if (feedbackName === "" || feedbackEmail === "" || feedbackMessage === "") {
        alert("All fields are required.");
        return false;
    }
    if (!emailRegex.test(feedbackEmail)) {
        alert("Please enter a valid email address.");
        return false;
    }

    return true; // Form is valid
}

document.addEventListener('DOMContentLoaded', function () {
    // User image upload and display
    const imageUpload = document.getElementById('image-upload');
    const profileImage = document.getElementById('profile-image');

    imageUpload.addEventListener('change', function (event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function (e) {
                profileImage.src = e.target.result; // Set the uploaded image as the profile picture
            };
            reader.readAsDataURL(file);
        }
    });

    // Preferences - Change background color
    const bgColorInput = document.getElementById('bg-color');
    const applyPreferencesButton = document.getElementById('apply-preferences');

    applyPreferencesButton.addEventListener('click', function () {
        document.body.style.backgroundColor = bgColorInput.value; // Change background color
    });

    // Mouse events for highlighting qualifications
    const qualificationSection = document.getElementById('qualification-section');

    qualificationSection.addEventListener('mouseenter', function () {
        qualificationSection.classList.add('highlight'); // Add highlight class on mouse enter
    });

    qualificationSection.addEventListener('mouseleave', function () {
        qualificationSection.classList.remove('highlight'); // Remove highlight class on mouse leave
    });

    // Context menu event for qualifications section
    qualificationSection.addEventListener('contextmenu', function (event) {
        event.preventDefault(); // Prevent default context menu
        alert('Custom context menu activated!'); // Show custom alert
    });
});

document.addEventListener('DOMContentLoaded', function () {
    // Display Browser Information
    const browserInfoDisplay = document.getElementById('browser-info-display');
    browserInfoDisplay.innerHTML = `
        <p>Browser Name: ${navigator.appName}</p>
        <p>Browser Version: ${navigator.appVersion}</p>
        <p>Platform: ${navigator.platform}</p>
        <p>User Agent: ${navigator.userAgent}</p>
        <p>Cookies Enabled: ${navigator.cookieEnabled}</p>
    `;

    // Window Operations
    let newWindow;

    document.getElementById('open-window').addEventListener('click', function () {
        newWindow = window.open('', 'New Window', 'width=400,height=400');
        newWindow.document.write('<h1>This is a new window!</h1>');
    });

    document.getElementById('close-window').addEventListener('click', function () {
        if (newWindow) {
            newWindow.close();
            newWindow = null;
        } else {
            alert('No window to close!');
        }
    });

    document.getElementById('resize-window').addEventListener('click', function () {
        if (newWindow) {
            newWindow.resizeTo(600, 600);
        } else {
            alert('No window to resize!');
        }
    });

    // Timer Controls
    let timer;
    let timerRunning = false;
    let seconds = 0;
    const timerDisplay = document.getElementById('timer-display');

    document.getElementById('start-timer').addEventListener('click', function () {
        if (!timerRunning) {
            timerRunning = true;
            timer = setInterval(function () {
                seconds++;
                timerDisplay.textContent = formatTime(seconds);
            }, 1000);
        }
    });

    document.getElementById('stop-timer').addEventListener('click', function () {
        if (timerRunning) {
            clearInterval(timer);
            timerRunning = false;
        }
    });

    function formatTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
    }

    // HTML Tag Insertion
    document.getElementById('insert-html').addEventListener('click', function () {
        const htmlInput = document.getElementById('html-input').value;
        const htmlDisplay = document.getElementById('html-display');

        try {
            const newElement = document.createRange().createContextualFragment(htmlInput);
            htmlDisplay.innerHTML = ''; // Clear previous content
            htmlDisplay.appendChild(newElement);
        } catch (error) {
            alert('Invalid HTML input!');
        }
    });
});
